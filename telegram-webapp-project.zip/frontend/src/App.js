import React from "react";

function App() {
  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h1>👋 Добро пожаловать в Telegram WebApp</h1>
      <button>Записаться</button>
    </div>
  );
}

export default App;